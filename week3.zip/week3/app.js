const express = require("express")
const app = express()
const port =80

app.get("/",(req, res)=>{
    res.send('first code using express')
})
app.post('/intro',(req,res)=>{
    res.send("hi! i am aqib ")
})

app.listen(port,()=>{
    console.log(`server created on port ${port}`)
})